// src/screens/L5SummaryScreen.js
import React, { useMemo, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, useWindowDimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import ScreenWrapper from '../components/ScreenWrapper';
import useStore from '../store/useStore';
import useThemeVars from '../hooks/useThemeVars';
import rawProbes from '../data/probes.v1.json';
import { estimateIntensity } from '../utils/intensity';

const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

// Compute adaptive max height for the pills block (same idea as L4)
function computePillsMaxHeight({
  windowHeight,
  insetsBottom = 0,
  headerH = 120,
  buttonBlock = 84,
  topBottomPadding = 32,
  safetyGap = 8,
  minH = 240,
  maxH = 680,
}) {
  const available = windowHeight - insetsBottom - headerH - buttonBlock - topBottomPadding;
  return clamp(available - safetyGap, minH, maxH);
}

export default function L5SummaryScreen({ navigation }) {
  const theme = useThemeVars();
  const insets = useSafeAreaInsets();
  const { height: WIN_H } = useWindowDimensions();

  // read from store
  const evidenceTags = useStore(s => s.sessionDraft?.evidenceTags ?? []);
  const pickedEmotion = useStore(s => s.decision?.top?.[0] ?? s.emotion ?? '-');
  const storeTriggers = useStore(s => s.l4?.triggers ?? []);
  const storeBM = useStore(s => s.l4?.bodyMind ?? []);

  // store setters (we will persist on "Continue")
  const setL4Triggers = useStore(s => s.setL4Triggers);
  const setL4BodyMind = useStore(s => s.setL4BodyMind);
  const setL4Intensity = useStore(s => s.setL4Intensity);

  // local editable copies
  const [editTrig, setEditTrig] = useState(storeTriggers);
  const [editBM, setEditBM] = useState(storeBM);
  const [intAdj, setIntAdj] = useState(0); // manual fine-tune: -2..+2

  // data sources (fallbacks kept)
  const probes = useMemo(() => ({
    triggers: Array.isArray(rawProbes?.triggers)
      ? rawProbes.triggers
      : Array.isArray(rawProbes?.L4_triggers)
        ? rawProbes.L4_triggers
        : ['Work', 'Conflict', 'Uncertainty', 'Deadlines', 'Fatigue'],
    bodyMind: Array.isArray(rawProbes?.bodyMind)
      ? rawProbes.bodyMind
      : Array.isArray(rawProbes?.L4_bodyMind)
        ? rawProbes.L4_bodyMind
        : ['Tight chest', 'Racing thoughts', 'Shallow breathing', 'Low energy', 'Irritable'],
  }), []);

  // live auto-intensity preview
  const { intensity: autoIntensity, confidence } = estimateIntensity({
    tags: evidenceTags,
    bodyMind: editBM,
    triggers: editTrig,
  });
  const previewIntensity = clamp(autoIntensity + intAdj, 0, 10);

  const pillsMaxHeight = computePillsMaxHeight({
    windowHeight: WIN_H,
    insetsBottom: insets.bottom,
    headerH: 120,
    buttonBlock: 84,
    topBottomPadding: 32,
    safetyGap: 8,
    minH: 220,
    maxH: Math.round(WIN_H * 0.92),
  });

  const s = makeStyles(theme, insets);

  const onContinue = () => {
    // persist edited selections
    setL4Triggers(editTrig);
    setL4BodyMind(editBM);
    setL4Intensity(previewIntensity);
    navigation.navigate('L6Actions');
  };

  return (
    <ScreenWrapper useFlexHeight style={{ backgroundColor: theme.bgcolor }}>
      <View style={s.wrap}>
        <Text style={s.title}>Summary</Text>
        <Text style={s.subtitle}>Review and adjust if needed before getting recommendations.</Text>

        {/* Emotion */}
        <View style={s.card}>
          <Text style={s.cardLabel}>Emotion</Text>
          <Text style={s.cardValue}>{String(pickedEmotion)}</Text>
          {/* If you want a "Change…" action later, add a button here */}
        </View>

        {/* Triggers (editable) */}
        <View style={s.card}>
          <Text style={s.cardLabel}>Triggers</Text>
          <EditablePills
            theme={theme}
            data={probes.triggers}
            selected={editTrig}
            onChange={setEditTrig}
            maxHeight={pillsMaxHeight}
          />
        </View>

        {/* Body & Mind (editable) */}
        <View style={s.card}>
          <Text style={s.cardLabel}>Body & Mind patterns</Text>
          <EditablePills
            theme={theme}
            data={probes.bodyMind}
            selected={editBM}
            onChange={setEditBM}
            maxHeight={pillsMaxHeight}
          />
        </View>

        {/* Intensity quick adjust */}
        <View style={s.card}>
          <Text style={s.cardLabel}>Intensity</Text>
          <Text style={s.intensityText}>
            {previewIntensity}/10
            <Text style={s.confNote}>  {confidence >= 0.7 ? 'Auto • accurate' : 'Auto • check'}</Text>
          </Text>
          <View style={s.row}>
            <SmallBtn label="-1" onPress={() => setIntAdj(a => Math.max(-2, a - 1))} />
            <SmallBtn label="Reset" onPress={() => setIntAdj(0)} />
            <SmallBtn label="+1" onPress={() => setIntAdj(a => Math.min( 2, a + 1))} />
          </View>
        </View>

        {/* Continue button */}
        <TouchableOpacity style={s.cta} onPress={onContinue}>
          <Text style={s.ctaText}>Continue</Text>
        </TouchableOpacity>
      </View>
    </ScreenWrapper>
  );
}

function EditablePills({ theme, data = [], selected = [], onChange, maxHeight = 400 }) {
  const s = pillsStyles(theme);
  const toggle = (t) => {
    const active = selected.includes(t);
    onChange(active ? selected.filter(x => x !== t) : [...selected, t]);
  };

  return (
    <View style={{ maxHeight }}>
      <ScrollView
        contentContainerStyle={{
          flexDirection: 'row',
          flexWrap: 'wrap',
          justifyContent: 'flex-start',
          paddingBottom: 8,
        }}
        showsVerticalScrollIndicator
      >
        {data.map((t) => {
          const active = selected.includes(t);
          return (
            <TouchableOpacity
              key={t}
              onPress={() => toggle(t)}
              style={[s.pill, active && s.pillActive]}
            >
              <Text style={s.pillText}>{t}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

function SmallBtn({ label, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={{
      paddingVertical: 8, paddingHorizontal: 12, borderRadius: 10, backgroundColor: '#00000010', marginRight: 8,
    }}>
      <Text style={{ fontWeight: '700' }}>{label}</Text>
    </TouchableOpacity>
  );
}

const makeStyles = (t, insets) => StyleSheet.create({
  wrap: { flex: 1, padding: 16, paddingBottom: (insets?.bottom ?? 0) + 72, backgroundColor: t.bgcolor },
  title: { fontSize: 28, fontWeight: '900', textAlign: 'center', color: t.textMain },
  subtitle: { fontSize: 14, fontWeight: '400', textAlign: 'center', color: t.card_choice_text, marginTop: 6, marginBottom: 12 },
  card: { backgroundColor: t.cardBg, borderRadius: 12, padding: 12, marginTop: 12, borderWidth: 1, borderColor: '#00000012' },
  cardLabel: { fontSize: 12, color: t.textSub, marginBottom: 8 },
  cardValue: { fontSize: 18, color: t.textMain, fontWeight: '700' },
  row: { flexDirection: 'row', alignItems: 'center', marginTop: 8 },
  intensityText: { fontSize: 18, fontWeight: '800', color: t.textMain },
  confNote: { fontSize: 12, fontWeight: '400', color: t.textSub },
  cta: {
    position: 'absolute', left: 16, right: 16,
    bottom: Math.max(8, (insets?.bottom ?? 0) + 8),
    padding: 14, borderRadius: 12, alignItems: 'center',
    backgroundColor: t.button,
  },
  ctaText: { color: '#fff', fontWeight: '800' },
});

const pillsStyles = (t) => StyleSheet.create({
  pill: {
    paddingVertical: 8, paddingHorizontal: 12,
    borderRadius: 999, backgroundColor: t.cardBg,
    margin: 6, borderWidth: 1, borderColor: '#00000022',
  },
  pillActive: { backgroundColor: t.button },
  pillText: { color: t.textMain },
});
