import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Dimensions } from 'react-native';
import useStore from '../store/useStore';
import useThemeVars from '../hooks/useThemeVars';
import ScreenWrapper from '../components/ScreenWrapper';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const P = Math.round(SCREEN_WIDTH * 0.05);
const P_LARGE = Math.round(SCREEN_WIDTH * 0.08);

/**
 * SettingsScreen — app settings and options.
 * Allows changing theme and clearing all history.
 */
export default function SettingsScreen() {
  // Theme colors for this screen
  const {
    background,
    textPrimary,
    textSecondary,
    cardBackground,
    dividerColor,
    dangerBackground,
    dangerText,
    themeName,
  } = useThemeVars();

    const rowDividerColor =
      themeName === 'light'
        ? 'rgba(0,0,0,0.06)'
        : 'rgba(255,255,255,0.16)';

  // Store methods: reset history, current theme, and theme setter
  const resetHistory = useStore((state) => state.resetHistory);
  const theme = useStore((state) => state.theme);
  const setTheme = useStore((state) => state.setTheme);

  // Switches app theme between light and dark
  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');

  // Shows alert confirmation before clearing all data
  const confirmReset = () => {
    Alert.alert(
      'Clear all history',
      'This will delete all your reflections permanently. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: resetHistory },
      ]
    );
  };

  return (
    <ScreenWrapper style={[styles.container, { backgroundColor: background }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={[styles.title, { color: textPrimary }]}>Settings</Text>
        <View style={[styles.divider, { backgroundColor: rowDividerColor }]} />
      </View>

      <View style={styles.content}>
        {/* Switch between Light and Dark theme */}
        <TouchableOpacity
          style={[
            styles.option,
            { borderTopWidth: 1, borderTopColor: rowDividerColor },
          ]}
          onPress={toggleTheme}
        >
          <Text style={[styles.optionText, { color: textPrimary }]}>
            Theme: {theme === 'light' ? 'Light' : 'Dark'}
          </Text>
        </TouchableOpacity>

        {/* Privacy Policy stub (no action yet) */}
        <TouchableOpacity
          style={[styles.option, { borderBottomColor: rowDividerColor }]}
          onPress={() => {
            // TODO: Show privacy policy screen
          }}
        >
          <Text style={[styles.optionText, { color: textPrimary }]}>
            Privacy Policy
          </Text>
        </TouchableOpacity>

        {/* Feedback stub (no action yet) */}
        <TouchableOpacity
          style={[styles.option, { borderBottomColor: rowDividerColor }]}
          onPress={() => {
            // TODO: Send feedback
          }}
        >
          <Text style={[styles.optionText, { color: textPrimary }]}>
            Send Feedback
          </Text>
        </TouchableOpacity>

        {/* Divider and version number */}
        <View style={[styles.divider, { backgroundColor: rowDividerColor }]} />
        <Text style={[styles.version, { color: textSecondary }]}>
          Version 1.0.0
        </Text>

        {/* Button to clear all history, with confirmation */}
        <TouchableOpacity
          style={[
            styles.clearButton,
            { backgroundColor: dangerBackground },
          ]}
          onPress={confirmReset}
        >
          <Text
            style={[
              styles.clearText,
              { color: dangerText },
            ]}
          >
            🗑 Clear reflection history
          </Text>
        </TouchableOpacity>
      </View>
    </ScreenWrapper>
  );
}

// ======= RESPONSIVE STYLES =======
const styles = StyleSheet.create({
  container: {
    minHeight: '100%',
    flex: 1,
  },
  header: {
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: P_LARGE,
    marginTop: P_LARGE,
  },
  title: {
    fontSize: Math.round(SCREEN_WIDTH * 0.08),
    fontWeight: '800',
    textAlign: 'center',
    alignSelf: 'center',
    marginBottom: P,
  },
  divider: {
    height: 1,
    width: Math.round(SCREEN_WIDTH * 0.5),
    alignSelf: 'center', 
    marginBottom: P_LARGE,
    borderRadius: 1,
  },
  content: {
    flexGrow: 1,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
    paddingHorizontal: P_LARGE,
    paddingBottom: P_LARGE,
  },
  option: {
    paddingVertical: Math.round(SCREEN_WIDTH * 0.048),
    borderBottomWidth: 1,
    minHeight: Math.round(SCREEN_WIDTH * 0.12),
    justifyContent: 'center',
  },
  optionText: {
    fontSize: Math.round(SCREEN_WIDTH * 0.042),
  },
  clearButton: {
    marginTop: P_LARGE,
    padding: Math.round(SCREEN_WIDTH * 0.04),
    borderRadius: Math.round(SCREEN_WIDTH * 0.03),
    alignItems: 'center',
  },
  clearText: {
    fontWeight: '700',
    fontSize: Math.round(SCREEN_WIDTH * 0.045),
  },
  version: {
    fontSize: Math.round(SCREEN_WIDTH * 0.037),
    textAlign: 'center',
    marginTop: Math.round(P_LARGE * 0.7),
    marginBottom: 6,
    letterSpacing: 0.2,
  },
});
