// Micro Selector (AE3)
// Selects micro state within macro based on evidence tags

import { getMicrosForMacro } from '../data/microTaxonomy.js';
import { getMicroEvidenceTags } from '../data/microEvidenceTags.js';

/**
 * Select micro state within macro based on evidence tags
 * Task AK3-POST-2: Changed back to sync (static import instead of dynamic)
 * @param {string} macroKey - Macro state key
 * @param {string[]} evidenceTags - Normalized evidence tags
 * @param {Object} options - Options: { threshold: number, preferSpecific: boolean }
 * @returns {{ microKey: string | null, score: number, matchedTags: string[] } | null}
 */
export function selectMicro(macroKey, evidenceTags, options = {}) {
  const {
    threshold = 0.3,
    preferSpecific = true,
  } = options;
  
  const micros = getMicrosForMacro(macroKey);
  
  if (micros.length === 0) {
    // Macro has no micros (e.g., uncertain)
    return null;
  }
  
  // Task AK3.4: Get must-have tags from microEvidenceTags for scoring boost
  // Task AK3-POST-2: Static import (no await needed)
  
  // Score each micro
  const microScores = micros.map(micro => {
    const matchedTags = [];
    let score = 0;
    
    // Task AK3.4: Check must-have tags (strong boost)
    const evidenceTagSet = getMicroEvidenceTags(micro.microKey);
    if (evidenceTagSet) {
      const mustHaveMatched = evidenceTagSet.mustHave.filter(tag => 
        evidenceTags.includes(tag)
      );
      const supportingMatched = evidenceTagSet.supporting.filter(tag => 
        evidenceTags.includes(tag)
      );
      
      // Task AK3.4: Must-have tags get strong multiplier
      // If all must-have match → strong boost (2x base)
      // If partial must-have → moderate boost (1.5x base)
      if (mustHaveMatched.length === evidenceTagSet.mustHave.length) {
        score += mustHaveMatched.length * 2.0; // All must-have: 2x multiplier
      } else if (mustHaveMatched.length > 0) {
        score += mustHaveMatched.length * 1.5; // Partial must-have: 1.5x multiplier
      }
      
      // Supporting tags: base weight
      score += supportingMatched.length * 1.0;
    }
    
    // Count matching evidence tags (fallback for micros without microEvidenceTags)
    for (const evidenceTag of evidenceTags) {
      // Direct match (only if not already counted in must-have/supporting)
      if (micro.evidenceTags.includes(evidenceTag)) {
        if (!matchedTags.includes(evidenceTag)) {
          matchedTags.push(evidenceTag);
          // Only add base weight if not already boosted by must-have
          if (!evidenceTagSet || !evidenceTagSet.mustHave.includes(evidenceTag)) {
            score += 1.0; // Base weight for direct match
          }
        }
      }
      
      // Optional weights (context/axis tags that boost this micro)
      if (micro.optionalWeights) {
        for (const [tag, weight] of Object.entries(micro.optionalWeights)) {
          if (evidenceTag.startsWith(tag)) {
            score += weight - 1.0; // Additional weight beyond base
          }
        }
      }
    }
    
    // Task AK3.4: Tag specificity bonus (stronger for must-have matches)
    const specificityBonus = preferSpecific && matchedTags.length > 0
      ? 1.0 / (1.0 + matchedTags.length * 0.1)
      : 0;
    
    return {
      micro,
      score: score + specificityBonus,
      matchedTags,
    };
  });
  
  // Sort by score (descending)
  microScores.sort((a, b) => b.score - a.score);
  
  // Task AK3.3: Dynamic threshold based on must-have match
  // If all must-have match, lower threshold (micro should be selected)
  const topMicro = microScores[0];
  if (topMicro) {
    const topEvidenceTagSet = getMicroEvidenceTags(topMicro.micro.microKey);
    let effectiveThreshold = threshold;
    
    if (topEvidenceTagSet) {
      const mustHaveMatched = topEvidenceTagSet.mustHave.filter(tag => 
        evidenceTags.includes(tag)
      );
      
      // Task AK3.3: If all must-have match, lower threshold significantly
      if (mustHaveMatched.length === topEvidenceTagSet.mustHave.length) {
        effectiveThreshold = Math.min(threshold, 0.1); // Very low threshold if all must-have match
      } else if (mustHaveMatched.length > 0) {
        effectiveThreshold = threshold * 0.7; // Moderate reduction for partial must-have
      }
    }
    
    if (topMicro.score >= effectiveThreshold) {
      // Check for ties
      const tiedMicros = microScores.filter(m => 
        Math.abs(m.score - topMicro.score) < 0.01
      );
      
      if (tiedMicros.length > 1) {
        // Tie: prefer more specific (fewer matched tags but higher score)
        const mostSpecific = tiedMicros.reduce((best, current) => {
          if (current.matchedTags.length < best.matchedTags.length) {
            return current;
          }
          return best;
        });
        
        return {
          microKey: mostSpecific.micro.microKey,
          score: mostSpecific.score,
          matchedTags: mostSpecific.matchedTags,
        };
      }
      
      return {
        microKey: topMicro.micro.microKey,
        score: topMicro.score,
        matchedTags: topMicro.matchedTags,
      };
    }
  }
  
  // No micro selected (score below threshold)
  return null;
}

/**
 * Check if micro should be null (weak/conflicting evidence)
 * Task AK3.3: Relaxed logic - only null if extremely weak evidence
 * @param {string} macroKey - Macro state key
 * @param {string[]} evidenceTags - Normalized evidence tags
 * @param {string} baselineConfidence - Baseline confidence band
 * @returns {boolean} True if micro should be null
 */
export function shouldMicroBeNull(macroKey, evidenceTags, baselineConfidence) {
  // Task AK3.3: Only null if baseline confidence is very low AND evidence is extremely weak
  // Previously: required sig.micro.* tags, now only check overall evidence strength
  if (baselineConfidence === 'low' && evidenceTags.length === 0) {
    return true; // No evidence at all
  }
  
  // Task AK3.3: Removed strict requirement for sig.micro.* tags
  // The selectMicro function already handles scoring and thresholding
  // If selectMicro returned a result, we should trust it (unless confidence is extremely low)
  
  // Only null if baseline is low AND we have very few tags (< 1)
  // This is a minimal check - selectMicro's threshold is the main gate
  if (baselineConfidence === 'low' && evidenceTags.length < 1) {
    return true;
  }
  
  return false;
}
